const router = require('express').Router();
const auth = require('../middleware/auth');
const ActivityLog = require('../models/ActivityLog');

// GET /activity/recent - last 10 logs (scoped to user unless admin)
router.get('/recent', auth, async (req, res) => {
  try {
    const query = req.user.role === 'admin' ? {} : { userId: req.user._id };

    const logs = await ActivityLog.find(query)
      .populate('userId', 'email')
      .populate('fileId', 'originalName')
      .sort({ timestamp: -1 })
      .limit(20);

    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
