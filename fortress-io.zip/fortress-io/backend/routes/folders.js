const router = require('express').Router();
const auth = require('../middleware/auth');
const Folder = require('../models/Folder');
const File = require('../models/File');

// POST /folders
router.post('/', auth, async (req, res) => {
  try {
    const { name, parentFolderId } = req.body;
    if (!name) return res.status(400).json({ message: 'Folder name required' });

    const folder = await Folder.create({
      name,
      ownerId: req.user._id,
      parentFolderId: parentFolderId || null
    });

    res.status(201).json({ message: 'Folder created', folder });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /folders - list all folders for user
router.get('/', auth, async (req, res) => {
  try {
    const query = req.user.role === 'admin' ? {} : { ownerId: req.user._id };
    const folders = await Folder.find(query).sort({ createdAt: -1 });
    res.json(folders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /folders/:id/files
router.get('/:id/files', auth, async (req, res) => {
  try {
    const folder = await Folder.findById(req.params.id);
    if (!folder) return res.status(404).json({ message: 'Folder not found' });

    if (folder.ownerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    const files = await File.find({ folderId: req.params.id })
      .populate('lockedBy', 'email')
      .sort({ createdAt: -1 });

    res.json({ folder, files });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
