const router = require('express').Router();
const path = require('path');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const QRCode = require('qrcode');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');
const File = require('../models/File');
const ActivityLog = require('../models/ActivityLog');

// Helper to log activity
async function logActivity(userId, action, fileId, details = '') {
  try {
    await ActivityLog.create({ userId, action, fileId, details });
  } catch (e) {
    console.error('Activity log error:', e.message);
  }
}

// ─── POST /files/upload ───────────────────────────────────────────────────────
router.post('/upload', auth, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });

    const { folderId, selfDestructMinutes } = req.body;

    let selfDestructAt = null;
    if (selfDestructMinutes && Number(selfDestructMinutes) > 0) {
      selfDestructAt = new Date(Date.now() + Number(selfDestructMinutes) * 60 * 1000);
    }

    const file = await File.create({
      name: req.file.filename,
      originalName: req.file.originalname,
      path: `uploads/${req.file.filename}`,
      mimetype: req.file.mimetype,
      size: req.file.size,
      folderId: folderId || null,
      ownerId: req.user._id,
      selfDestructAt
    });

    await logActivity(req.user._id, 'upload', file._id, `Uploaded "${file.originalName}"`);

    res.status(201).json({ message: 'File uploaded', file });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── GET /files/:id ───────────────────────────────────────────────────────────
router.get('/:id', auth, async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) return res.status(404).json({ message: 'File not found' });

    // Only owner or admin can view
    if (file.ownerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    await logActivity(req.user._id, 'download', file._id, `Downloaded "${file.originalName}"`);

    const filePath = path.join(__dirname, '..', file.path);
    res.download(filePath, file.originalName);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── DELETE /files/:id ────────────────────────────────────────────────────────
router.delete('/:id', auth, async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) return res.status(404).json({ message: 'File not found' });

    // Only owner or admin
    if (file.ownerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Locked check: only the locker can delete
    if (file.isLocked && file.lockedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(423).json({ message: 'File is locked by another user' });
    }

    // Remove from disk
    const filePath = path.join(__dirname, '..', file.path);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    await logActivity(req.user._id, 'delete', file._id, `Deleted "${file.originalName}"`);
    await File.findByIdAndDelete(file._id);

    res.json({ message: 'File deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── POST /files/:id/lock ─────────────────────────────────────────────────────
router.post('/:id/lock', auth, async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) return res.status(404).json({ message: 'File not found' });

    if (file.isLocked) {
      return res.status(423).json({ message: `File already locked by another user` });
    }

    file.isLocked = true;
    file.lockedBy = req.user._id;
    file.lockedAt = new Date();
    await file.save();

    await logActivity(req.user._id, 'lock', file._id, `Locked "${file.originalName}"`);

    res.json({ message: 'File locked', file });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── POST /files/:id/unlock ───────────────────────────────────────────────────
router.post('/:id/unlock', auth, async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) return res.status(404).json({ message: 'File not found' });

    if (!file.isLocked) {
      return res.status(400).json({ message: 'File is not locked' });
    }

    // Only the user who locked it (or admin) can unlock
    if (file.lockedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Only the user who locked this file can unlock it' });
    }

    file.isLocked = false;
    file.lockedBy = null;
    file.lockedAt = null;
    await file.save();

    await logActivity(req.user._id, 'unlock', file._id, `Unlocked "${file.originalName}"`);

    res.json({ message: 'File unlocked', file });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── GET /files/:id/qr ────────────────────────────────────────────────────────
router.get('/:id/qr', auth, async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) return res.status(404).json({ message: 'File not found' });

    if (file.ownerId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Create a short-lived token (default 5 min)
    const expiresIn = Number(process.env.QR_JWT_EXPIRES_IN) || 300;
    const tempToken = jwt.sign(
      { fileId: file._id, type: 'qr_download' },
      process.env.JWT_SECRET,
      { expiresIn }
    );

    const downloadUrl = `${process.env.CLIENT_URL || 'http://localhost:5000'}/files/download/${tempToken}`;
    const qrDataUrl = await QRCode.toDataURL(downloadUrl);

    await logActivity(req.user._id, 'qr_share', file._id, `Generated QR for "${file.originalName}" (expires in ${expiresIn}s)`);

    res.json({ qr: qrDataUrl, downloadUrl, expiresIn });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── GET /files/download/:token (QR download - no auth required) ──────────────
router.get('/download/:token', async (req, res) => {
  try {
    const decoded = jwt.verify(req.params.token, process.env.JWT_SECRET);
    if (decoded.type !== 'qr_download') {
      return res.status(400).json({ message: 'Invalid token type' });
    }

    const file = await File.findById(decoded.fileId);
    if (!file) return res.status(404).json({ message: 'File not found or already deleted' });

    const filePath = path.join(__dirname, '..', file.path);
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: 'File not found on disk' });

    res.download(filePath, file.originalName);
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'QR link has expired' });
    }
    res.status(500).json({ message: err.message });
  }
});

// ─── GET /files (list all files for user) ────────────────────────────────────
router.get('/', auth, async (req, res) => {
  try {
    const query = req.user.role === 'admin' ? {} : { ownerId: req.user._id };
    const files = await File.find(query)
      .populate('lockedBy', 'email')
      .sort({ createdAt: -1 });
    res.json(files);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
