const mongoose = require('mongoose');

const ActivityLogSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  action: {
    type: String,
    enum: ['upload', 'download', 'delete', 'lock', 'unlock', 'auto_delete', 'qr_share'],
    required: true
  },
  fileId: { type: mongoose.Schema.Types.ObjectId, ref: 'File', default: null },
  details: { type: String, default: '' },
  timestamp: { type: Date, default: Date.now }
}, { timestamps: false });

module.exports = mongoose.model('ActivityLog', ActivityLogSchema);
