const mongoose = require('mongoose');

const FileSchema = new mongoose.Schema({
  name: { type: String, required: true },
  originalName: { type: String, required: true },
  path: { type: String, required: true },          // relative path on disk
  mimetype: { type: String },
  size: { type: Number },
  folderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Folder', default: null },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  // Locking
  isLocked: { type: Boolean, default: false },
  lockedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  lockedAt: { type: Date, default: null },

  // Self-destruct
  selfDestructAt: { type: Date, default: null }
}, { timestamps: true });

module.exports = mongoose.model('File', FileSchema);
