require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');
const cron = require('node-cron');

const app = express();

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ─── Ensure upload directory exists ──────────────────────────────────────────
const uploadDir = path.join(__dirname, process.env.UPLOAD_DIR || 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// ─── Routes ──────────────────────────────────────────────────────────────────
app.use('/auth', require('./routes/auth'));
app.use('/files', require('./routes/files'));
app.use('/folders', require('./routes/folders'));
app.use('/activity', require('./routes/activity'));

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', app: 'Fortress.io' }));

// ─── MongoDB Connection ───────────────────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/fortressio')
  .then(() => {
    console.log('✅ MongoDB connected');
    startCronJobs();
  })
  .catch(err => { console.error('❌ MongoDB error:', err); process.exit(1); });

// ─── Cron: Auto-delete expired files ─────────────────────────────────────────
function startCronJobs() {
  const File = require('./models/File');
  const ActivityLog = require('./models/ActivityLog');

  // Runs every minute
  cron.schedule('* * * * *', async () => {
    try {
      const now = new Date();
      const expiredFiles = await File.find({
        selfDestructAt: { $ne: null, $lte: now }
      });

      for (const file of expiredFiles) {
        // Remove physical file
        const filePath = path.join(__dirname, file.path);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }

        // Log the auto-delete
        await ActivityLog.create({
          userId: file.ownerId,
          action: 'auto_delete',
          fileId: file._id,
          details: `File "${file.name}" auto-deleted (self-destruct timer expired)`
        });

        // Remove DB record
        await File.findByIdAndDelete(file._id);
        console.log(`🗑️  Auto-deleted expired file: ${file.name}`);
      }
    } catch (err) {
      console.error('Cron job error:', err);
    }
  });

  console.log('⏰ Cron jobs started');
}

// ─── Start Server ─────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Fortress.io backend running on port ${PORT}`);
});
