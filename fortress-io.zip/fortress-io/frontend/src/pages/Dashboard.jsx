import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useAuth } from '../AuthContext';

const api = axios.create();
api.interceptors.request.use(cfg => {
  cfg.headers.Authorization = `Bearer ${localStorage.getItem('token')}`;
  return cfg;
});

const ACTION_ICONS = {
  upload: '⬆️', download: '⬇️', delete: '🗑️',
  lock: '🔒', unlock: '🔓', auto_delete: '💥', qr_share: '📱'
};

function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleString();
}

function formatSize(bytes) {
  if (!bytes) return '—';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function timeLeft(date) {
  if (!date) return null;
  const diff = new Date(date) - Date.now();
  if (diff <= 0) return 'Expired';
  const m = Math.floor(diff / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (m > 60) return `${Math.floor(m / 60)}h ${m % 60}m`;
  return `${m}m ${s}s`;
}

// ─── Upload Modal ─────────────────────────────────────────────────────────────
function UploadModal({ folders, onClose, onUploaded }) {
  const [file, setFile] = useState(null);
  const [folderId, setFolderId] = useState('');
  const [selfDestructMinutes, setSelfDestructMinutes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return setError('Select a file');
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      if (folderId) fd.append('folderId', folderId);
      if (selfDestructMinutes) fd.append('selfDestructMinutes', selfDestructMinutes);
      await api.post('/files/upload', fd);
      onUploaded();
      onClose();
    } catch (err) {
      setError(err.response?.data?.message || 'Upload failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-fortress-card border border-fortress-border rounded-2xl p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold text-white mb-4">Upload File</h3>
        <form onSubmit={handleUpload} className="space-y-4">
          <div>
            <label className="block text-sm text-slate-400 mb-1">File *</label>
            <input type="file" onChange={e => setFile(e.target.files[0])}
              className="w-full text-sm text-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:bg-fortress-accent file:text-white file:text-sm cursor-pointer" />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Folder (optional)</label>
            <select value={folderId} onChange={e => setFolderId(e.target.value)}
              className="w-full bg-slate-800 border border-fortress-border rounded-lg px-3 py-2 text-white text-sm">
              <option value="">No folder</option>
              {folders.map(f => <option key={f._id} value={f._id}>{f.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">🔥 Self-Destruct Timer (minutes)</label>
            <input type="number" min="1" value={selfDestructMinutes}
              onChange={e => setSelfDestructMinutes(e.target.value)}
              placeholder="Leave empty for permanent"
              className="w-full bg-slate-800 border border-fortress-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-fortress-accent" />
            {selfDestructMinutes && (
              <p className="text-xs text-orange-400 mt-1">
                ⚠️ File will auto-delete after {selfDestructMinutes} minute(s)
              </p>
            )}
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose}
              className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg text-sm transition">
              Cancel
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 bg-fortress-accent hover:bg-indigo-500 disabled:opacity-50 text-white py-2 rounded-lg text-sm transition">
              {loading ? 'Uploading...' : 'Upload'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── QR Modal ─────────────────────────────────────────────────────────────────
function QRModal({ file, onClose }) {
  const [qr, setQr] = useState(null);
  const [url, setUrl] = useState('');
  const [expires, setExpires] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/files/${file._id}/qr`).then(res => {
      setQr(res.data.qr);
      setUrl(res.data.downloadUrl);
      setExpires(res.data.expiresIn);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [file._id]);

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-fortress-card border border-fortress-border rounded-2xl p-6 w-full max-w-sm text-center">
        <h3 className="text-lg font-semibold text-white mb-1">QR Share</h3>
        <p className="text-sm text-slate-400 mb-4">{file.originalName}</p>
        {loading ? <p className="text-slate-400 py-8">Generating...</p> : (
          <>
            <img src={qr} alt="QR Code" className="mx-auto w-48 h-48 rounded-lg border border-slate-600" />
            <p className="text-xs text-orange-400 mt-3">⏱️ Expires in {expires}s</p>
            <div className="mt-3 bg-slate-800 rounded px-3 py-2 text-xs text-slate-300 break-all">{url}</div>
          </>
        )}
        <button onClick={onClose} className="mt-4 w-full bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg text-sm transition">
          Close
        </button>
      </div>
    </div>
  );
}

// ─── File Card ────────────────────────────────────────────────────────────────
function FileCard({ file, currentUser, onRefresh }) {
  const [loading, setLoading] = useState('');
  const [showQR, setShowQR] = useState(false);
  const [timer, setTimer] = useState('');

  // Live countdown
  useEffect(() => {
    if (!file.selfDestructAt) return;
    const iv = setInterval(() => setTimer(timeLeft(file.selfDestructAt)), 1000);
    return () => clearInterval(iv);
  }, [file.selfDestructAt]);

  const isOwner = file.ownerId === currentUser.id || file.ownerId?._id === currentUser.id;
  const isLocker = file.lockedBy?._id === currentUser.id || file.lockedBy === currentUser.id;
  const canModify = !file.isLocked || isLocker || currentUser.role === 'admin';

  const handleLock = async () => {
    setLoading('lock');
    try {
      await api.post(`/files/${file._id}/${file.isLocked ? 'unlock' : 'lock'}`);
      onRefresh();
    } catch (err) {
      alert(err.response?.data?.message || 'Error');
    } finally { setLoading(''); }
  };

  const handleDelete = async () => {
    if (!confirm(`Delete "${file.originalName}"?`)) return;
    setLoading('delete');
    try {
      await api.delete(`/files/${file._id}`);
      onRefresh();
    } catch (err) {
      alert(err.response?.data?.message || 'Error');
    } finally { setLoading(''); }
  };

  const handleDownload = () => {
    window.open(`/files/${file._id}`, '_blank');
  };

  return (
    <>
      <div className="bg-fortress-card border border-fortress-border rounded-xl p-4 hover:border-slate-500 transition group">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <span className="text-2xl shrink-0">📄</span>
            <div className="min-w-0">
              <p className="font-medium text-white text-sm truncate">{file.originalName}</p>
              <p className="text-xs text-slate-500">{formatSize(file.size)} · {formatDate(file.createdAt)}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {file.isLocked && (
              <span className="px-2 py-0.5 bg-yellow-900/40 text-yellow-400 text-xs rounded-full border border-yellow-700">
                🔒 Locked
              </span>
            )}
          </div>
        </div>

        {/* Self-destruct badge */}
        {file.selfDestructAt && (
          <div className="mt-2 px-2 py-1 bg-red-900/30 border border-red-800 rounded text-xs text-red-400">
            💥 Self-destructs in: <span className="font-mono font-bold">{timer || timeLeft(file.selfDestructAt)}</span>
          </div>
        )}

        {file.isLocked && file.lockedBy && (
          <p className="text-xs text-yellow-600 mt-1.5">
            Locked by: {file.lockedBy.email || 'someone'} at {formatDate(file.lockedAt)}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2 mt-3">
          <button onClick={handleDownload}
            className="flex-1 py-1.5 text-xs bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition">
            ⬇️ Download
          </button>
          {(isOwner || currentUser.role === 'admin') && (
            <button onClick={handleLock} disabled={loading === 'lock' || (file.isLocked && !isLocker && currentUser.role !== 'admin')}
              className="flex-1 py-1.5 text-xs bg-yellow-700/40 hover:bg-yellow-700/60 text-yellow-300 rounded-lg transition disabled:opacity-40">
              {loading === 'lock' ? '...' : file.isLocked ? '🔓 Unlock' : '🔒 Lock'}
            </button>
          )}
          <button onClick={() => setShowQR(true)}
            className="flex-1 py-1.5 text-xs bg-purple-700/40 hover:bg-purple-700/60 text-purple-300 rounded-lg transition">
            📱 QR
          </button>
          {canModify && (
            <button onClick={handleDelete} disabled={loading === 'delete'}
              className="py-1.5 px-3 text-xs bg-red-900/40 hover:bg-red-900/60 text-red-400 rounded-lg transition">
              {loading === 'delete' ? '...' : '🗑️'}
            </button>
          )}
        </div>
      </div>
      {showQR && <QRModal file={file} onClose={() => setShowQR(false)} />}
    </>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
export default function Dashboard() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('files');
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);
  const [activity, setActivity] = useState([]);
  const [showUpload, setShowUpload] = useState(false);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [fRes, folRes, aRes] = await Promise.all([
        api.get('/files'),
        api.get('/folders'),
        api.get('/activity/recent')
      ]);
      setFiles(fRes.data);
      setFolders(folRes.data);
      setActivity(aRes.data);
    } catch (err) {
      console.error(err);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const createFolder = async (e) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;
    await api.post('/folders', { name: newFolderName });
    setNewFolderName('');
    setShowNewFolder(false);
    fetchAll();
  };

  const filteredFiles = selectedFolder
    ? files.filter(f => f.folderId === selectedFolder)
    : files.filter(f => !f.folderId);

  return (
    <div className="min-h-screen flex bg-fortress-dark">
      {/* ── Sidebar ── */}
      <aside className="w-64 shrink-0 bg-fortress-card border-r border-fortress-border flex flex-col">
        <div className="p-5 border-b border-fortress-border">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏰</span>
            <span className="font-bold text-white text-lg">Fortress<span className="text-fortress-accent">.io</span></span>
          </div>
          <p className="text-xs text-slate-500 mt-1">{user?.email}</p>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { id: 'files', label: '📄 All Files', count: files.length },
            { id: 'folders', label: '📁 Folders', count: folders.length },
            { id: 'activity', label: '📊 Activity', count: activity.length },
          ].map(item => (
            <button key={item.id} onClick={() => { setTab(item.id); setSelectedFolder(null); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm transition ${
                tab === item.id ? 'bg-fortress-accent text-white' : 'text-slate-400 hover:bg-slate-700 hover:text-white'
              }`}>
              <span>{item.label}</span>
              <span className="text-xs opacity-60">{item.count}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-fortress-border">
          <button onClick={logout}
            className="w-full text-left text-sm text-slate-500 hover:text-red-400 transition px-3 py-2">
            🚪 Sign Out
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <main className="flex-1 flex flex-col min-h-0 overflow-hidden">
        {/* Header */}
        <header className="border-b border-fortress-border px-6 py-4 flex items-center justify-between shrink-0">
          <div>
            <h1 className="text-lg font-semibold text-white capitalize">{
              selectedFolder ? `📁 ${folders.find(f => f._id === selectedFolder)?.name}` :
              tab === 'files' ? '📄 All Files' :
              tab === 'folders' ? '📁 Folders' : '📊 Activity Log'
            }</h1>
            <p className="text-xs text-slate-500">
              {tab === 'files' ? `${filteredFiles.length} files` :
               tab === 'folders' ? `${folders.length} folders` :
               `${activity.length} recent events`}
            </p>
          </div>
          <div className="flex gap-2">
            {tab === 'folders' && (
              <button onClick={() => setShowNewFolder(!showNewFolder)}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm rounded-lg transition">
                + New Folder
              </button>
            )}
            {(tab === 'files' || selectedFolder) && (
              <button onClick={() => setShowUpload(true)}
                className="px-4 py-2 bg-fortress-accent hover:bg-indigo-500 text-white text-sm rounded-lg transition">
                ⬆️ Upload File
              </button>
            )}
            <button onClick={fetchAll}
              className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white text-sm rounded-lg transition">
              🔄
            </button>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading && (
            <div className="flex items-center justify-center py-20">
              <div className="text-slate-400">Loading...</div>
            </div>
          )}

          {/* New Folder Form */}
          {showNewFolder && tab === 'folders' && (
            <form onSubmit={createFolder} className="mb-4 flex gap-2">
              <input value={newFolderName} onChange={e => setNewFolderName(e.target.value)}
                placeholder="Folder name..." autoFocus
                className="flex-1 bg-slate-800 border border-fortress-border rounded-lg px-4 py-2 text-white text-sm focus:outline-none focus:border-fortress-accent" />
              <button type="submit" className="px-4 py-2 bg-fortress-accent text-white text-sm rounded-lg hover:bg-indigo-500 transition">
                Create
              </button>
              <button type="button" onClick={() => setShowNewFolder(false)}
                className="px-3 py-2 bg-slate-700 text-white text-sm rounded-lg hover:bg-slate-600 transition">
                Cancel
              </button>
            </form>
          )}

          {/* FILES TAB */}
          {(tab === 'files' || selectedFolder) && !loading && (
            <>
              {filteredFiles.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-4xl mb-3">📭</p>
                  <p className="text-slate-400">No files yet. Upload one!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredFiles.map(f => (
                    <FileCard key={f._id} file={f} currentUser={user} onRefresh={fetchAll} />
                  ))}
                </div>
              )}
            </>
          )}

          {/* FOLDERS TAB */}
          {tab === 'folders' && !selectedFolder && !loading && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {folders.map(folder => {
                const count = files.filter(f => f.folderId === folder._id).length;
                return (
                  <button key={folder._id} onClick={() => { setSelectedFolder(folder._id); setTab('files'); }}
                    className="bg-fortress-card border border-fortress-border hover:border-indigo-500 rounded-xl p-5 text-left transition group">
                    <span className="text-4xl block mb-2">📁</span>
                    <p className="font-medium text-white text-sm truncate">{folder.name}</p>
                    <p className="text-xs text-slate-500 mt-1">{count} file{count !== 1 ? 's' : ''}</p>
                  </button>
                );
              })}
              {folders.length === 0 && (
                <div className="col-span-4 text-center py-20">
                  <p className="text-4xl mb-3">📂</p>
                  <p className="text-slate-400">No folders yet. Create one!</p>
                </div>
              )}
            </div>
          )}

          {/* ACTIVITY TAB */}
          {tab === 'activity' && !loading && (
            <div className="space-y-2 max-w-2xl">
              {activity.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-4xl mb-3">📊</p>
                  <p className="text-slate-400">No activity yet</p>
                </div>
              ) : activity.map(log => (
                <div key={log._id} className="bg-fortress-card border border-fortress-border rounded-xl px-4 py-3 flex items-center gap-3">
                  <span className="text-xl shrink-0">{ACTION_ICONS[log.action] || '📋'}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white">{log.details || log.action}</p>
                    <p className="text-xs text-slate-500">
                      {log.userId?.email || 'System'} · {formatDate(log.timestamp)}
                    </p>
                  </div>
                  <span className={`px-2 py-0.5 text-xs rounded-full border ${
                    log.action === 'delete' || log.action === 'auto_delete' ? 'bg-red-900/30 text-red-400 border-red-800' :
                    log.action === 'lock' ? 'bg-yellow-900/30 text-yellow-400 border-yellow-800' :
                    log.action === 'unlock' ? 'bg-green-900/30 text-green-400 border-green-800' :
                    log.action === 'upload' ? 'bg-blue-900/30 text-blue-400 border-blue-800' :
                    'bg-slate-700 text-slate-400 border-slate-600'
                  }`}>
                    {log.action}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Modals */}
      {showUpload && <UploadModal folders={folders} onClose={() => setShowUpload(false)} onUploaded={fetchAll} />}
    </div>
  );
}
