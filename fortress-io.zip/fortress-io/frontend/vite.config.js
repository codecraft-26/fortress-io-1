import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/auth': 'http://localhost:5000',
      '/files': 'http://localhost:5000',
      '/folders': 'http://localhost:5000',
      '/activity': 'http://localhost:5000',
    }
  }
})
