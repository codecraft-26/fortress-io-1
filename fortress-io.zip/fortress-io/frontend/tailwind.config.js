/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        fortress: {
          dark: '#0f172a',
          card: '#1e293b',
          border: '#334155',
          accent: '#6366f1',
          danger: '#ef4444',
          success: '#22c55e',
          warning: '#f59e0b',
        }
      }
    }
  },
  plugins: []
}
